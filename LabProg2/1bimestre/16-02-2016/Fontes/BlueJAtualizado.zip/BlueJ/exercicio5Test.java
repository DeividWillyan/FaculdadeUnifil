import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * A classe de teste exercicio5Test.
 *
 * @author  (seu nome)
 * @version (um número de versão ou data)
 */
public class exercicio5Test {
   
    @Test
    public void exercicio5() {
           
        assertEquals(8998, exercicio5.pares());
       
    }    
}
