public class No {        
    
    private No proximo;
    private Object valor;
       
    public No getProximo(){
        return this.proximo;
    }   
    
    public void setProximo(No proximo){
        this.proximo = proximo;
    }
    
    public Object getValor(){
        return this.valor;
    }   
    
    public void setValor(Object valor){
        this.valor = valor;
    }  
    
}
