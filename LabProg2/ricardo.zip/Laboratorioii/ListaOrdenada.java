
/**
 * Write a description of class ListaOrdenada here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ListaOrdenada
{
    public ListaOrdenada(int capacidade) {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    public ListaOrdenada() {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    
    
    public int inserir(Comparable obj) {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    
    
    public Comparable remover(int pos) {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    
    
    public int buscar(Comparable obj) {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    
    
    public Comparable elementoEm(int pos) {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    
    
    public void limpar() {
        throw new UnsupportedOperationException("Ainda não implementado pelo aluno");
    }
    
    
    private Comparable[] arranjo;
    private int numElementos;
}
