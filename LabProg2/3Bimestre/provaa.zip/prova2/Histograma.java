
/**
 * Write a description of class Histograma here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Histograma
{
    /**
     * Constructor for objects of class Histograma
     */
    public Histograma(String s) {
        throw new UnsupportedOperationException("O aluno ainda não implementou este método.");
    }
}
