#include "uniterm.h"
#include <stdio.h>

int main(int argc, char * argv[]) {
	printf("\n Iniciando Terminal \n");
	uniterm_laco_principal();
	return 0;
}
